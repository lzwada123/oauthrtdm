#!/bin/bash


JAVA_XMS='-Xms512m'
JAVA_XMX='-Xmx1024m'

applicationName='proxyRtdm.jar'


getPid() {
    
    PID=`ps ax | grep $applicationName |  grep -v "grep" | awk '{print $1}'`
    echo "$PID"
}

start() {

  INITPID=`getPid`	
 
  if [ "$INITPID" == "" ]; then	
     java   $JAVA_XMS $JAVA_XMX   -jar $applicationName > init.out 2>&1 &
  fi   

  echo "Running on PID:" `getPid` 
  
}  

stop() {

  KILLPID=`getPid`


  if [ "$KILLPID" !=  "" ]; then
  	kill -9 $KILLPID
  else
  	echo "Application is not running ..."	  
  fi
}

case "$1" in 
    start)
       start
       ;;
    stop)
       stop
       ;;
    restart)
       stop
       start
       ;;
    status)
       
       STPID=`getPid`
       
       if [ "$STPID" != "" ]; then
	   echo "Application in running on PID:" $STPID
       else       
	   echo  "Application is no running..."
       fi		       
       
       ;;
    *)
       echo "Usage: $0 {start|stop|status|restart}"
esac

exit 0 


